const dbConfig = require("../config/db.config.js");
module.exports = {
    'url' : 'mongodb://mongodb_users:27017/' 
};
