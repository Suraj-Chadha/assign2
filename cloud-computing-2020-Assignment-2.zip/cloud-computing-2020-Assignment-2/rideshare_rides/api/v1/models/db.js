const dbConfig = require("../config/db.config.js");
module.exports = {
    'url' : 'mongodb://mongodb_rides:27017/' 
};
